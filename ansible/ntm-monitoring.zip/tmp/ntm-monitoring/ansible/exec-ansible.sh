SCRIPT_PARAM=$1
SCRIPT_HOME=$(dirname $(readlink -f $0))
KEY_FILE=${SCRIPT_HOME}/server.pem

###### FUNCTIONS ######

callSshAgent()
{
		echo "Starting the ssh agent"
                eval `ssh-agent -s`
                echo "Started, SSH_AGENT_PID=${SSH_AGENT_PID} "
		ssh-add ${KEY_FILE}
		echo "Loaded, Git key [${KEY_FILE}}]"
}

killSshAgent()
{
        re='^[0-9]+$'
        if [ ! -z ${SSH_AGENT_PID} ] && [[ ${SSH_AGENT_PID} =~ $re ]]
        then
                kill -9 ${SSH_AGENT_PID}
                echo "INFO: SSH_AGENT_PID=${SSH_AGENT_PID} was killed"
        else
                echo "ERROR: SSH_AGENT_PID=${SSH_AGENT_PID}, and it is not a real PID"
                return 1
        fi
        return 0
}
##########################

######### MAIN ##########


callSshAgent $KEY_FILE
ansible-playbook -i  ${SCRIPT_HOME}/ntm-hosts  ${SCRIPT_HOME}/ntm-monitoring.yml ${SCRIPT_PARAM} -vvvv
killSshAgent
